# Each folder includes the ratings in two domain.

# The users are distributed into two domains��and they are not overlapped.

# Form: {userID,  itemID, rating} 